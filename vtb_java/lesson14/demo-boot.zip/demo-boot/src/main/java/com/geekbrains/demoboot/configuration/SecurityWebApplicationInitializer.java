package com.geekbrains.demoboot.configuration;

// import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;
import org.springframework.stereotype.Component;

@Component
public class SecurityWebApplicationInitializer { // extends AbstractSecurityWebApplicationInitializer {
}
